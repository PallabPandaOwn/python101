# Listing out different characteristics  of a song

Artist ="Shyam kumar" # Artist of song
Genre = "Jazz" # gener of song
YearReleased = 2020 # year of realesed
Duration = 120.5 # duration of song
Music = "ABC Company" # music company

print(Artist)
print(Genre)
print(YearReleased)
print(Duration)
print(Music)
