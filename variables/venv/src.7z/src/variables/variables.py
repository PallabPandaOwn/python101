
#Global fucntions
one = 1
One = 2
print(one,One)

stringvar = 'hello world'
print(stringvar)

def function1():
    var1 = 1

    return

# mouse + cat + dog = "small"+"medium"+"large"
# print("cat)

function1()
print(var1)#error because of out of scope
